"""Complete EADP32 versus AnchorZip32 under identical wait-only CLIP protocol."""
import argparse,datetime,hashlib,json
from pathlib import Path
from collections import defaultdict
import numpy as np
import score_pope_streamwait_control as ctl
OUT=ctl.OUT

def main():
 parser=argparse.ArgumentParser()
 parser.add_argument('--az-result',type=Path,default=OUT/'pope_v15_AZ32_streamwait.jsonl')
 parser.add_argument('--eadp-result',type=Path,default=OUT/'pope_v15_EADP32_streamwait.jsonl')
 parser.add_argument('--az-protocol',type=Path,default=OUT/'pope_v15_AZ32_streamwait.protocol.json')
 parser.add_argument('--eadp-protocol',type=Path,default=OUT/'pope_v15_EADP32_streamwait.protocol.json')
 parser.add_argument('--az-control-report',type=Path,default=OUT/'pope_v15_AZ32_streamwait.comparison.json')
 parser.add_argument('--out',type=Path,default=OUT/'pope_v15_EADP32_streamwait.fair_comparison.json')
 parser.add_argument('--marker',type=Path)
 parser.add_argument('--generation-returncode',type=int)
 args=parser.parse_args()
 if args.marker:
  assert args.generation_returncode==0, 'release requires EADP generator returncode0'
  assert not args.marker.exists(), 'refuse overwrite marker'
 assert not args.out.exists(), 'refuse overwrite full fair comparison'
 ap=json.loads(args.az_protocol.read_text());ep=json.loads(args.eadp_protocol.read_text())
 for p in [ap,ep]:
  assert p['generation_exit_code']==0 and p['question_count']==8910, 'both protocols require completed legal generations'
  assert p['production_sources_modified'] is False and p['record_stream_added'] is False
  assert p['AST_validation']['restoration_ast_identical'] is True
 assert ap['parameters']['anchorzip'] is True and ep['parameters']['anchorzip'] is False
 aparams={k:v for k,v in ap['parameters'].items() if k!='anchorzip'}
 eparams={k:v for k,v in ep['parameters'].items() if k!='anchorzip'}
 assert aparams==eparams, 'only AnchorZip install flag may differ'
 assert aparams['visual_token_num']==32 and aparams['alpha']==.5 and aparams['beta']==2. and aparams['temperature']==0 and aparams['max_new_tokens']==128 and aparams['conv_mode']=='vicuna_v1'
 for key in ['source_and_input_sha256','launcher_source_sha256','question_sha256','question_file','image_folder']:
  assert ap[key]==ep[key], f'fair source/input identity differs: {key}'
 for key in ['original_forward_ast_sha256','patched_forward_ast_sha256','inserted_nodes','restoration_ast_identical']:
  assert ap['AST_validation'][key]==ep['AST_validation'][key], f'AST intervention differs: {key}'
 for filename,expected in ap['source_and_input_sha256'].items():
  assert hashlib.sha256(Path(filename).read_bytes()).hexdigest()==expected, f'frozen source/input changed: {filename}'
 im=OUT/'pope_v15_AZ32.images.json'
 for identity in json.loads(im.read_text())['identities']:
  assert hashlib.sha256(Path(identity['path']).read_bytes()).hexdigest()==identity['bytes_sha256'], f'image changed: {identity["image"]}'
 az_report=json.loads(args.az_control_report.read_text())
 assert az_report['success'] is True and az_report['n']==8910 and az_report['generation_returncode']==0
 assert az_report['sha256'][str(args.az_result)]==hashlib.sha256(args.az_result.read_bytes()).hexdigest(), 'AZ prior score must match exact predictions'
 qs=[json.loads(l) for l in ctl.QF.read_text().splitlines()];qby={str(q['question_id']):q for q in qs}
 assert len(qs)==len(qby)==8910
 _,az=ctl.load_predictions(args.az_result,qby,True);_,eadp=ctl.load_predictions(args.eadp_result,qby,True)
 scores={name:ctl.score('pope',f,question_file=ctl.QF,annotation_dir=ctl.EV) for name,f in [('AnchorZip32',args.az_result),('EADP32',args.eadp_result)]}
 assert scores['AnchorZip32']['categories']==az_report['scores']['wait_only']['categories'], 'AZ score changed'
 groups=defaultdict(list)
 for q in qs:groups[(q['image'],q['text'])].append(str(q['question_id']))
 stability={'AnchorZip32':ctl.group_stats(groups,az),'EADP32':ctl.group_stats(groups,eadp)}
 counts={'AnchorZip32':ctl.image_confusions(qs,az),'EADP32':ctl.image_confusions(qs,eadp)}
 n_images=counts['EADP32'].shape[0];rng=np.random.default_rng(20261008)
 weights=rng.multinomial(n_images,np.full(n_images,1/n_images),size=5000)
 delta=ctl.f1_macro(weights@counts['AnchorZip32'])-ctl.f1_macro(weights@counts['EADP32'])
 diff=ctl.comparison(qs,eadp,az)
 diff['average_f1_delta_AZ_minus_EADP']=scores['AnchorZip32']['summary']['average_f1']-scores['EADP32']['summary']['average_f1']
 diff['unrounded_average_f1_delta']=float(ctl.f1_macro(counts['AnchorZip32'].sum(axis=0))[0]-ctl.f1_macro(counts['EADP32'].sum(axis=0))[0])
 diff['image_cluster_bootstrap']={'n_images':n_images,'replicates':5000,'seed':20261008,'ci95':list(map(float,np.quantile(delta,[.025,.975]))),'bootstrap_mean':float(delta.mean())}
 resolved=all(s['parsed_disagreement_groups']==0 for s in stability.values())
 result={'success':True,'n':8910,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scores':scores,'stability':stability,'comparison':diff,'parameters_except_anchorzip':aparams,'protocol_difference':'EADP does not install AnchorZip; both use identical dynamic wait-only CLIP patch. Lambda recorded but unused by EADP.','generation_exit_codes':{'AnchorZip32':ap['generation_exit_code'],'EADP32':ep['generation_exit_code']},'no_parsed_repeated_input_disagreements_in_either_run':resolved,'limitations':['Each arm has one complete run; no independent full replicate.','Concurrent NeXT workload sample/timing changes over time.','Marker means legal complete generation and scoring, not a positive scientific finding.'],'sha256':{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in [args.az_result,args.eadp_result,args.az_protocol,args.eadp_protocol,args.az_control_report,ctl.QF,im,Path(__file__),Path(ctl.__file__)]}}
 ctl.atomic_json(args.out,result)
 scorefile=args.eadp_result.with_suffix('.official.score.json');ctl.atomic_json(scorefile,scores['EADP32'])
 if args.marker:
  ctl.atomic_json(args.marker,{'success':True,'n_per_run':8910,'n_control_runs':2,'generation_exit_codes':result['generation_exit_codes'],'az_control_report':str(args.az_control_report),'fair_comparison_file':str(args.out),'eadp_scorefile':str(scorefile),'parsed_disagreement_groups':{name:s['parsed_disagreement_groups'] for name,s in stability.items()},'delta_f1_AZ_minus_EADP':diff['average_f1_delta_AZ_minus_EADP'],'ci95':diff['image_cluster_bootstrap']['ci95'],'completed_utc':result['completed_utc'],'release_meaning':'Both controls completed and scored with full integrity; independent of direction or remaining disagreements'})
 print(json.dumps({'n':8910,'f1':{name:s['summary']['average_f1'] for name,s in scores.items()},'parsed_disagreement_groups':{name:s['parsed_disagreement_groups'] for name,s in stability.items()},'AZ_minus_EADP':diff['average_f1_delta_AZ_minus_EADP'],'ci95':diff['image_cluster_bootstrap']['ci95'],'marker':str(args.marker) if args.marker else None}))
if __name__=='__main__':main()
