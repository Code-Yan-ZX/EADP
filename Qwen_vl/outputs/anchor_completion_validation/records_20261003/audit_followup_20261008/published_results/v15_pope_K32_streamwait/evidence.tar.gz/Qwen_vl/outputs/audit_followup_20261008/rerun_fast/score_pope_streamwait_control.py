"""Strict full-run three-way POPE control, score then optionally release queue."""
import argparse
from pathlib import Path
from collections import Counter,defaultdict
import datetime,hashlib,json,sys
import numpy as np
ROOT=Path('/media/disk2/YZX/research/EADP_amp')
OUT=ROOT/'Qwen_vl/outputs/audit_followup_20261008/rerun_fast'
SCRIPT=ROOT/'Qwen_vl/scripts/stage1_roundtrip_pilot'
sys.path.insert(0,str(SCRIPT))
from official_score import score
from rescore_official_20261008 import pope_parse,_pope_key
QF=ROOT/'LLaVA/playground/data/eval/pope/llava_pope_test.jsonl'
EV=QF.parent

def atomic_json(path,data):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 temp=path.with_name(path.name+'.tmp');temp.write_text(json.dumps(data,indent=2)+'\n');temp.replace(path)

def load_predictions(path,by_question,trace):
 rows=[json.loads(line) for line in Path(path).read_text().splitlines()]
 ids=[str(r['question_id']) for r in rows]
 assert len(rows)==8910 and len(set(ids))==8910 and set(ids)==set(by_question), 'requires all8910 unique expected IDs'
 for row in rows:
  assert row['prompt']==by_question[str(row['question_id'])]['text'], 'fullprompt differs'
  text=row.get('text');assert isinstance(text,str) and text.strip() and not text.strip().upper().startswith('FAILED'), 'empty/FAILED answer'
  if trace:
   assert row.get('metadata',{}).get('actual_visual_tokens_retained')==32, 'runtime token budget must be32'
 return rows,{str(r['question_id']):r for r in rows}

def group_stats(groups,by_pred):
 stats=[]
 for (image,prompt),ids in groups.items():
  if len(ids)<2:continue
  parsed={pope_parse(by_pred[q]['text']) for q in ids}
  raw={by_pred[q]['text'] for q in ids}
  stats.append({'image':image,'prompt':prompt,'question_ids':ids,'answers':{q:by_pred[q]['text'] for q in ids},'parsed_disagreement':len(parsed)>1,'raw_disagreement':len(raw)>1})
 return {'n_groups':len(stats),'parsed_disagreement_groups':sum(s['parsed_disagreement'] for s in stats),'raw_disagreement_groups':sum(s['raw_disagreement'] for s in stats),'disagreement_groups':[s for s in stats if s['parsed_disagreement'] or s['raw_disagreement']]}

def comparison(questions,a,b):
 trans=Counter();changed=[];raw_changed=0
 for q in questions:
  qid=str(q['question_id']);pa=pope_parse(a[qid]['text']);pb=pope_parse(b[qid]['text'])
  trans[(pa,pb)]+=1;raw_changed+=a[qid]['text']!=b[qid]['text']
  if pa!=pb:changed.append({'question_id':qid,'image':q['image'],'category':q['category'],'before':a[qid]['text'],'after':b[qid]['text']})
 return {'n_changed_parsed':len(changed),'n_changed_raw':raw_changed,'transitions':{f'{a}->{b}':n for (a,b),n in trans.items()},'changed_answers':changed}

def image_confusions(questions,pred):
 images=sorted({q['image'] for q in questions});iid={v:i for i,v in enumerate(images)}
 cats=['random','popular','adversarial'];cid={v:i for i,v in enumerate(cats)};labels={}
 for cat in cats:
  gt=[json.loads(l) for l in (EV/f'coco_pope_{cat}.json').read_text().splitlines()]
  labels[cat]={_pope_key(g['image'],g['text']):g['label'] for g in gt}
 counts=np.zeros((len(images),12),dtype=np.int64)
 for q in questions:
  p=pope_parse(pred[str(q['question_id'])]['text']);g=labels[q['category']][_pope_key(q['image'],q['text'])]
  col=0 if p=='yes' and g=='yes' else 1 if p=='yes' else 2 if g=='no' else 3
  counts[iid[q['image']],cid[q['category']]*4+col]+=1
 return counts

def f1_macro(confusions):
 matrix=np.asarray(confusions).reshape(-1,3,4).astype(float)
 denom=2*matrix[:,:,0]+matrix[:,:,1]+matrix[:,:,3]
 f1=np.divide(200*matrix[:,:,0],denom,out=np.zeros_like(denom),where=denom>0)
 return f1.mean(axis=1)

def main():
 parser=argparse.ArgumentParser()
 parser.add_argument('--wait-result',type=Path,default=OUT/'pope_v15_AZ32_streamwait.jsonl')
 parser.add_argument('--asis-result',type=Path,default=OUT/'pope_v15_AZ32.jsonl')
 parser.add_argument('--legacy-result',type=Path,default=ROOT/'LLaVA/playground/data/eval/anchorzip_p3/pope/LRMAIN00625.jsonl')
 parser.add_argument('--out',type=Path,default=OUT/'pope_v15_AZ32_streamwait.comparison.json')
 parser.add_argument('--marker',type=Path)
 parser.add_argument('--generation-returncode',type=int)
 args=parser.parse_args()
 if args.marker:
  assert args.generation_returncode==0, 'release marker requires confirmed generator returncode0'
  assert not args.marker.exists(), 'refuse overwrite existing control marker'
 assert not args.out.exists(), 'refuse overwrite existing control comparison'
 protocol_file=OUT/'pope_v15_AZ32.protocol.json'
 frozen=json.loads(protocol_file.read_text())['source_and_input_sha256']
 for filename,expected in frozen.items():
  assert hashlib.sha256(Path(filename).read_bytes()).hexdigest()==expected, f'Frozen as-is source/input changed: {filename}'
 image_manifest=OUT/'pope_v15_AZ32.images.json'
 for identity in json.loads(image_manifest.read_text())['identities']:
  assert hashlib.sha256(Path(identity['path']).read_bytes()).hexdigest()==identity['bytes_sha256'], f'Image changed: {identity["image"]}'
 questions=[json.loads(l) for l in QF.read_text().splitlines()];by_question={str(q['question_id']):q for q in questions}
 assert len(questions)==len(by_question)==8910
 groups=defaultdict(list)
 for q in questions:groups[(q['image'],q['text'])].append(str(q['question_id']))
 files={'legacy':args.legacy_result,'asis':args.asis_result,'wait_only':args.wait_result}
 scores={};predictions={};stability={};runtime={};counts={}
 # All integrity gates precede any output write or queue release.
 for name,path in files.items():
  rows,predictions[name]=load_predictions(path,by_question,name!='legacy')
  scores[name]=score('pope',path,question_file=QF,annotation_dir=EV)
  stability[name]=group_stats(groups,predictions[name])
  runtime[name]=dict(Counter(r.get('metadata',{}).get('actual_visual_tokens_retained') for r in rows))
  counts[name]=image_confusions(questions,predictions[name])
 rng=np.random.default_rng(20261008)
 n_images=counts['asis'].shape[0]
 weights=rng.multinomial(n_images,np.full(n_images,1/n_images),size=5000)
 boot={name:f1_macro(weights@matrix) for name,matrix in counts.items()}
 pairs={}
 for a,b in [('legacy','asis'),('legacy','wait_only'),('asis','wait_only')]:
  key=f'{b}_minus_{a}';delta=boot[b]-boot[a]
  pairs[key]=comparison(questions,predictions[a],predictions[b])
  pairs[key]['average_f1_delta']=scores[b]['summary']['average_f1']-scores[a]['summary']['average_f1']
  pairs[key]['unrounded_average_f1_delta']=float(f1_macro(counts[b].sum(axis=0))[0]-f1_macro(counts[a].sum(axis=0))[0])
  pairs[key]['image_cluster_bootstrap']={'n_images':n_images,'replicates':5000,'seed':20261008,'ci95':list(map(float,np.quantile(delta,[.025,.975]))),'bootstrap_mean':float(delta.mean())}
 new_disagreements=stability['wait_only']['parsed_disagreement_groups']
 old_disagreements=stability['asis']['parsed_disagreement_groups']
 conclusion=("wait-only full run removed the observed repeated-input parsed disagreements; supports this synchronization intervention under the tested concurrent setup, with no independent repeat" if new_disagreements==0 and old_disagreements>0 else "wait-only full run still has repeated-input parsed disagreements; synchronization alone did not establish reproducibility")
 hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [QF,*files.values(),Path(__file__),protocol_file,image_manifest,ROOT/'LLaVA/llava/model/multimodal_encoder/clip_encoder.py']}
 result={'success':True,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'n':8910,'protocol':'as-asked8910 random2910, exact fullprompt/image identity, alpha0.5 beta2.0 lambda0.25 greedy vicuna, K32, wait-only dynamic source patch','generation_returncode':args.generation_returncode,'scores':scores,'stability':stability,'runtime_token_counts':runtime,'pairs':pairs,'conclusion':conclusion,'limitations':['One full control per configuration; cannot separate every nondeterminism mechanism.','Same GPU, concurrent NeXT TextVQA lane; source mathematics and parameters unchanged.','Scores are of complete predictions; no selection by favorable score.'],'sha256':hashes}
 atomic_json(args.out,result)
 scorefile=args.wait_result.with_suffix('.official.score.json');atomic_json(scorefile,scores['wait_only'])
 if args.marker:
  atomic_json(args.marker,{'success':True,'generation_returncode':0,'n':8910,'comparison_file':str(args.out),'scorefile':str(scorefile),'wait_only_disagreement_groups':new_disagreements,'asis_disagreement_groups':old_disagreements,'conclusion':conclusion,'completed_utc':result['completed_utc']})
 print(json.dumps({'n':8910,'f1':{k:v['summary']['average_f1'] for k,v in scores.items()},'parsed_disagreements':{k:v['parsed_disagreement_groups'] for k,v in stability.items()},'pairs':{k:{'delta_f1':v['average_f1_delta'],'ci95':v['image_cluster_bootstrap']['ci95'],'n_changed':v['n_changed_parsed']} for k,v in pairs.items()},'conclusion':conclusion,'marker':str(args.marker) if args.marker else None}))
if __name__=='__main__':main()
