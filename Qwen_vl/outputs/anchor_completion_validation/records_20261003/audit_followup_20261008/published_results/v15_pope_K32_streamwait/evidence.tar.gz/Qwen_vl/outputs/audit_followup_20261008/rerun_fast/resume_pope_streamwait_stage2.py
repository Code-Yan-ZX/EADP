"""Resume the frozen EADP32 worker after a zero-memory Ollama context blocked it.

Only the idle original controller is replaced. Generation, prediction paths,
the dynamic stream intervention and the fair scorer stay unchanged.
"""
from __future__ import annotations

import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback

ROOT = Path('/media/disk2/YZX/research/EADP_amp')
OUT = ROOT / 'Qwen_vl/outputs/audit_followup_20261008/rerun_fast'
STATE = OUT / 'pope_v15_AZ32_streamwait.controller.state.json'
WORKER = OUT / 'run_pope_streamwait_control.py'
PLAN = OUT / 'pope_v15_EADP32_streamwait.plan.json'
SCORER = OUT / 'score_pope_streamwait_baseline.py'
MARKER = OUT / 'pope_v15_AZ32.stream_control.finished.json'
MEASURED_V15_PEAK_MIB = 19134
SAFETY_BUFFER_MIB = 400
MIN_FREE_MIB = MEASURED_V15_PEAK_MIB + SAFETY_BUFFER_MIB


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic(path, value):
    temporary = Path(str(path) + '.tmp')
    temporary.write_text(json.dumps(value, indent=2))
    os.replace(temporary, path)


def process(pid):
    root = Path(f'/proc/{pid}')
    try:
        return dict(pid=pid, exists=True,
                    command=(root/'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace'),
                    status=(root/'status').read_text(),
                    children=[int(p) for p in (root/f'task/{pid}/children').read_text().split()])
    except OSError:
        return dict(pid=pid, exists=False, command='', children=[])


def classify(entries, free_mib, min_free_mib=MIN_FREE_MIB):
    ignored = [p for p in entries if p['memory_mib'] == 0 and p['command'].startswith('/usr/local/bin/ollama runner ')]
    others = [p for p in entries if p not in ignored]
    positive = [p for p in others if p['memory_mib'] > 0]
    next_models = [p for p in positive if '--model-path /media/disk2/YZX/doct/FastV/llava-v1.6-vicuna-7b' in p['command']]
    reasons = []
    if len(next_models) != 1 or len(others) != 1:
        reasons.append('require_exactly_one_authorized_resident_NeXT_model_and_no_unknown_context')
    if free_mib < min_free_mib:
        reasons.append('insufficient_free_GPU_memory')
    return dict(ready=not reasons, reasons=reasons, ignored_known_zero_memory_ollama_contexts=ignored,
                resident_processes=positive, entries=entries, free_memory_mib=free_mib,
                required_free_memory_mib=min_free_mib,
                measured_v15_peak_mib=MEASURED_V15_PEAK_MIB, safety_buffer_mib=SAFETY_BUFFER_MIB)


def gpu_gate():
    lines = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,used_gpu_memory',
                                     '--format=csv,noheader,nounits'], text=True).strip().splitlines()
    entries = []
    for line in lines:
        pid, memory = [value.strip() for value in line.split(',')]
        info = process(int(pid))
        entries.append(dict(pid=int(pid), memory_mib=int(memory), command=info['command'], proc_exists=info['exists']))
    free = int(subprocess.check_output(['nvidia-smi', '--query-gpu=memory.free',
                                        '--format=csv,noheader,nounits'], text=True).strip())
    return classify(entries, free)


def validate_first_stage(state, plan):
    assert state['status'] == 'waiting_for_next_concurrency' and state.get('child_pid') is None
    assert state['current_stage'] == 2 and [stage['stage'] for stage in state['completed_stages']] == [1]
    assert not MARKER.exists()
    assert plan['parameters']['anchorzip'] is False and plan['parameters']['visual_token_num'] == 32
    assert sha(WORKER) == plan['launcher_source_sha256']
    verified = {}
    for filename, digest in plan['source_and_input_sha256'].items():
        assert sha(filename) == digest, 'Frozen source/input drift: ' + filename
        verified[filename] = digest
    az_path = OUT/'pope_v15_AZ32_streamwait.jsonl'
    protocol_path = OUT/'pope_v15_AZ32_streamwait.protocol.json'
    report_path = OUT/'pope_v15_AZ32_streamwait.comparison.json'
    score_path = OUT/'pope_v15_AZ32_streamwait.official.score.json'
    protocol = json.loads(protocol_path.read_text())
    report = json.loads(report_path.read_text())
    score = json.loads(score_path.read_text())
    assert protocol['generation_exit_code'] == 0 and protocol['question_count'] == 8910
    assert report['success'] is True and report['n'] == 8910 and report['generation_returncode'] == 0
    assert report['sha256'][str(az_path)] == sha(az_path)
    assert protocol['source_and_input_sha256'] == plan['source_and_input_sha256']
    assert protocol['launcher_source_sha256'] == plan['launcher_source_sha256']
    assert score['categories'] == report['scores']['wait_only']['categories']
    questions = [json.loads(line) for line in Path(plan['question_file']).open()]
    rows = [json.loads(line) for line in az_path.open()]
    qby = {str(row['question_id']): row for row in questions}
    assert len(rows) == len(questions) == len(qby) == 8910
    ids = [str(row['question_id']) for row in rows]
    assert len(set(ids)) == 8910 and set(ids) == set(qby)
    for row in rows:
        assert row['prompt'] == qby[str(row['question_id'])]['text']
        assert str(row.get('text', '')).strip() not in ('', 'FAILED')
        assert row.get('metadata', {}).get('actual_visual_tokens_retained') == 32
    for filename in (plan['output'], plan['log'], plan['protocol_sidecar']):
        assert not Path(filename).exists(), 'Preserve existing stage2 artifact: ' + filename
    return dict(n_first_stage=8910, first_stage_validated=True,
                source_and_input_sha256=verified,
                preserved_first_stage_sha256={str(path):sha(path) for path in [az_path, protocol_path, report_path, score_path]},
                worker_sha256=sha(WORKER), scorer_sha256=sha(SCORER), recovery_launcher_sha256=sha(__file__))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--generate', action='store_true')
    args = parser.parse_args()
    original = json.loads(STATE.read_text())
    plan = json.loads(PLAN.read_text())
    evidence = validate_first_stage(original, plan)
    idle = process(original['controller_pid'])
    is_original = str(WORKER) + ' --generate' in idle['command']
    is_idle_recovery = str(Path(__file__).resolve()) + ' --generate' in idle['command']
    if args.generate and original['controller_pid'] == 1684451 and not idle['exists']:
        # Root-authorized memory-buffer adjustment stopped this idle recovery
        # before changing its source. The original controller was already
        # safely replaced; keep its archived evidence and reuse the same lock.
        previously_stopped_recovery = True
    else:
        previously_stopped_recovery = False
        assert idle['exists'] and (is_original or is_idle_recovery) and not idle['children']
    evidence.update(prepared_utc=now(), old_controller=idle, initial_gpu_gate=gpu_gate())
    if not args.generate:
        print(json.dumps(evidence, indent=2))
        return
    old_pid = original['controller_pid']
    # Freeze only this verified idle supervisor, then recheck there was no
    # child-launch race before terminating it. Never signal a GPU worker.
    if not previously_stopped_recovery:
        os.kill(old_pid, signal.SIGSTOP)
        try:
            stopped = process(old_pid)
            latest = json.loads(STATE.read_text())
            assert stopped['exists'] and not stopped['children']
            assert latest['status'] == 'waiting_for_next_concurrency' and latest.get('child_pid') is None
        except Exception:
            os.kill(old_pid, signal.SIGCONT)
            raise
        os.kill(old_pid, signal.SIGTERM)
        os.kill(old_pid, signal.SIGCONT)
    for _ in range(100):
        if not process(old_pid)['exists']:
            break
        time.sleep(.02)
    assert not process(old_pid)['exists'], 'Idle controller did not exit'
    lock = STATE.with_suffix('.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    archived = OUT/f'pope_v15_AZ32_streamwait.controller.state.before_resume.{stamp}.json'
    STATE.rename(archived)
    evidence.update(original_state_archive=str(archived), stopped_idle_controller_only=True)
    evidence_path = OUT/'pope_streamwait_stage2_recovery.json'
    atomic(evidence_path, evidence)
    state = dict(original, controller_pid=os.getpid(), resumed_utc=now(), current_stage=2,
                 status='waiting_for_next_concurrency', child_pid=None, stage_output=plan['output'],
                 recovery_evidence=str(evidence_path), recovery_launcher=str(Path(__file__).resolve()), updated_utc=now())
    atomic(STATE, state)
    try:
        ready = gpu_gate()
        while not ready['ready']:
            state.update(status='waiting_for_next_concurrency', gpu_gate=ready, child_pid=None, updated_utc=now())
            atomic(STATE, state)
            time.sleep(5)
            ready = gpu_gate()
        for filename, digest in evidence['source_and_input_sha256'].items():
            assert sha(filename) == digest
        assert sha(WORKER) == evidence['worker_sha256'] and sha(SCORER) == evidence['scorer_sha256']
        protocol = dict(plan, started_utc=now(), concurrency_at_launch=ready,
                        scorer_source_sha256=evidence['scorer_sha256'], controlled_group_size=2,
                        controlled_group_stage=2, recovery_evidence=str(evidence_path),
                        recovery_source_sha256=evidence['recovery_launcher_sha256'],
                        frozen_mode_note='mode=rtg applies only when AnchorZip installation is enabled')
        atomic(Path(plan['protocol_sidecar']), protocol)
        env = dict(os.environ, PYTHONPATH=str(ROOT/'LLaVA'), HF_HUB_OFFLINE='1',
                   TRANSFORMERS_OFFLINE='1', OMP_NUM_THREADS='4', MKL_NUM_THREADS='4')
        with Path(plan['log']).open('x') as log:
            worker = subprocess.Popen(plan['generate_command'], cwd=ROOT/'LLaVA', env=env,
                                      stdout=log, stderr=subprocess.STDOUT)
            state.update(status='generating', child_pid=worker.pid, concurrency_at_launch=ready, updated_utc=now())
            atomic(STATE, state)
            returned = worker.wait()
        if returned:
            raise RuntimeError(f'Frozen stage2 worker failed: {returned}')
        protocol.update(generation_exit_code=0, generation_finished_utc=now())
        atomic(Path(plan['protocol_sidecar']), protocol)
        state.update(status='scoring', child_pid=None, generation_returncode=0, updated_utc=now())
        atomic(STATE, state)
        assert sha(SCORER) == evidence['scorer_sha256']
        subprocess.run([sys.executable, str(SCORER), '--generation-returncode', '0', '--marker', str(MARKER)],
                       cwd=ROOT, env=env, check=True)
        assert json.loads(MARKER.read_text())['success'] is True
        state['completed_stages'].append(dict(stage=2, output=plan['output'], protocol=plan['protocol_sidecar'], completed_utc=now()))
        state.update(status='complete', marker=str(MARKER), updated_utc=now())
        atomic(STATE, state)
    except Exception as error:
        state.update(status='failed', error=str(error), child_pid=None, updated_utc=now())
        atomic(STATE, state)
        traceback.print_exc()
        raise


if __name__ == '__main__':
    main()
