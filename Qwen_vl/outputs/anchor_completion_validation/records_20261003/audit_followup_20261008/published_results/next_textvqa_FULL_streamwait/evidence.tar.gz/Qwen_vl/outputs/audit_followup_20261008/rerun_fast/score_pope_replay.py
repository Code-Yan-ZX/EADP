"""Complete-input scoring and comparison; never interprets a partial file as full."""
from pathlib import Path
from collections import Counter, defaultdict
import json,sys,subprocess,hashlib,datetime
ROOT=Path('/media/disk2/YZX/research/EADP_amp')
OUT=ROOT/'Qwen_vl/outputs/audit_followup_20261008/rerun_fast'
SCRIPT=ROOT/'Qwen_vl/scripts/stage1_roundtrip_pilot'
sys.path.insert(0,str(SCRIPT))
from official_score import score
from rescore_official_20261008 import pope_parse, _pope_key
QF=ROOT/'LLaVA/playground/data/eval/pope/llava_pope_test.jsonl'
EV=QF.parent
NEW=OUT/'pope_v15_AZ32.jsonl'
OLD=ROOT/'LLaVA/playground/data/eval/anchorzip_p3/pope/LRMAIN00625.jsonl'

def load(p):
 rows=[json.loads(l) for l in p.read_text().splitlines()]
 by={str(r['question_id']):r for r in rows}
 if len(rows)!=len(by): raise ValueError(f'duplicate IDs {p}')
 return rows,by

def stable(keys,by):
 groups=[]
 for key,ids in keys.items():
  if len(ids)<2: continue
  parsed={pope_parse(by[q]['text']) for q in ids}
  texts={by[q]['text'] for q in ids}
  groups.append({'image':key[0],'prompt':key[1],'question_ids':ids,'parsed_disagreement':len(parsed)>1,'raw_disagreement':len(texts)>1,'answers':{q:by[q]['text'] for q in ids}})
 return groups

qs,qby=load(QF); nr,new=load(NEW); oldr,old=load(OLD)
assert set(new)==set(qby)==set(old) and len(nr)==8910
for r in nr:
 assert r['prompt']==qby[str(r['question_id'])]['text']
 assert r.get('metadata',{}).get('actual_visual_tokens_retained') == 32
 text_value = r.get('text')
 assert isinstance(text_value, str) and text_value.strip() and not text_value.strip().upper().startswith('FAILED')
sc=score('pope',NEW,question_file=QF,annotation_dir=EV)
oscore=score('pope',OLD,question_file=QF,annotation_dir=EV)
(OUT/'pope_v15_AZ32.official.score.json').write_text(json.dumps(sc,indent=2)+'\n')
keys=defaultdict(list)
for q in qs: keys[(q['image'],q['text'])].append(str(q['question_id']))
ng=stable(keys,new); og=stable(keys,old)
transitions=Counter(); changed=[]
for q in qs:
 qid=str(q['question_id']); np=pope_parse(new[qid]['text']); op=pope_parse(old[qid]['text'])
 transitions[(op,np)]+=1
 if op!=np: changed.append({'question_id':qid,'image':q['image'],'category':q['category'],'old':old[qid]['text'],'new':new[qid]['text']})
counts=Counter(r.get('metadata',{}).get('actual_visual_tokens_retained') for r in nr)
result={'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'n':8910,'inputs_identical':True,'new_score':sc,'old_score':oscore,'delta_average_f1':sc['summary']['average_f1']-oscore['summary']['average_f1'],'n_changed_parsed_answers':len(changed),'n_changed_raw_answers':sum(new[k]['text']!=old[k]['text'] for k in qby),'transitions':{f'{a}->{b}':n for (a,b),n in transitions.items()},'repeated_input_groups':len(ng),'new_parsed_disagreement_groups':sum(g['parsed_disagreement'] for g in ng),'old_parsed_disagreement_groups':sum(g['parsed_disagreement'] for g in og),'new_raw_disagreement_groups':sum(g['raw_disagreement'] for g in ng),'old_raw_disagreement_groups':sum(g['raw_disagreement'] for g in og),'runtime_retained_token_counts':dict(counts),'source_and_predictions_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [QF,NEW,OLD,Path(__file__)]},'changed_parsed_answers':changed,'new_disagreement_groups':[g for g in ng if g['parsed_disagreement']],'old_disagreement_groups':[g for g in og if g['parsed_disagreement']]}
(OUT/'pope_v15_AZ32.replay_comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['n','delta_average_f1','n_changed_parsed_answers','transitions','repeated_input_groups','new_parsed_disagreement_groups','old_parsed_disagreement_groups','runtime_retained_token_counts']}))
print(json.dumps({'new':sc['categories'],'old':oscore['categories']}))
