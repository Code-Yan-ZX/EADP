"""Prepare frozen full controls; --run alone registers and starts their scope."""
from __future__ import annotations
import argparse
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

OUT=Path(__file__).resolve().parent
STABILITY=OUT/'stability'
ROOT=Path('/media/disk2/YZX/research/EADP_amp')
BATCH=ROOT/'Qwen_vl/outputs/audit_followup_20261008/rerun_batch'
PLAN=STABILITY/'next_text_full_streamwait.controller.plan.json'
STATE=STABILITY/'next_text_full_streamwait.controller.state.json'
WORKER=STABILITY/'next_text_full_streamwait.py'
ARMS=('EADP_beta2','AZ_beta2','EADP_beta1')
MIN_FREE=22500

def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);loaded=importlib.util.module_from_spec(spec);spec.loader.exec_module(loaded);return loaded

UTIL=module(OUT/'schedule_next_gap_panel.py','frozen_panel_scheduler_util')
read,sha,atomic,now,process=UTIL.read,UTIL.sha,UTIL.atomic,UTIL.now,UTIL.process

def verify(plan):
    for filename,expected in plan['source_and_input_sha256'].items():
        if sha(filename)!=expected:raise ValueError('Frozen source/input drift: '+filename)
    if sha(__file__)!=plan['controller_sha256']:raise ValueError('Frozen full controller drift')

def protected(job):
    for name in ('prediction','runtime','native_protocol','state','score','finished','log'):
        path=Path(job['output_paths'][name])
        if path.exists():raise FileExistsError('Preserve existing full-control artifact: '+str(path))

def prerequisites():
    lanes=UTIL.lane_snapshot();panel=read(OUT/'stream_panel_scheduler.state.json')
    marker=OUT/'stream_panel_scheduler.finished.json'
    panel_ready=(panel['status']=='complete' and panel.get('child_pid') is None
                 and not process(panel.get('supervisor_pid'))['alive']
                 and marker.is_file() and read(marker).get('success') is True
                 and panel.get('validation',{}).get('n')==128)
    return dict(ready=all(lane['complete'] for lane in lanes) and panel_ready,
                main_lanes=lanes,panel_complete_and_exited=panel_ready)

def first_json(path):
    try:
        with Path(path).open() as stream:line=stream.readline()
        return bool(line.endswith('\n') and isinstance(json.loads(line),dict))
    except (OSError,ValueError):return False

def has_progress(job):
    # worker.state and empty runtime files precede model loading.
    return first_json(job['output_paths']['prediction']) or first_json(job['output_paths']['runtime'])

def gate(gpu,active,progress,dependencies_ready):
    ignored=[];contexts=[];reasons=[]
    for entry in gpu['entries']:
        if entry['memory_mib']==0 and entry.get('alive') and entry['command'].startswith('/usr/local/bin/ollama runner '):ignored.append(entry)
        else:contexts.append(entry)
    if not dependencies_ready:reasons.append('main_queues_or_panel_not_complete_and_exited')
    if len(active)>=2:reasons.append('two_owned_loading_or_running_reservations')
    if any(entry['pid'] not in active for entry in contexts):reasons.append('unknown_or_foreign_GPU_context')
    if len(contexts)>1:reasons.append('no_third_GPU_context')
    if active:
        resident={entry['pid'] for entry in contexts if entry.get('alive') and entry['memory_mib']>0}
        if any(pid not in resident or not progress.get(pid,False) for pid in active):
            reasons.append('first_worker_loading_reservation_not_released')
    if gpu['free_mib']<MIN_FREE:reasons.append('insufficient_free_GPU_memory')
    return dict(ready=not reasons,reasons=reasons,contexts=contexts,ignored_zero_memory_ollama=ignored,
                free_mib=gpu['free_mib'],minimum_free_mib=MIN_FREE,owned_reserved_pids=sorted(active))

def expected_groups(selected):
    groups=['next_textvqa_K32_streamwait']
    if 'EADP_beta1' in selected:groups.append('next_textvqa_K32_default_beta1')
    return groups

def eligible(arm,completed):
    return arm!='EADP_beta1' or completed.get('EADP_beta2',{}).get('success') is True

def prepare(include_default):
    sources={};jobs={}
    for arm in ARMS:
        path=STABILITY/f'next_text_K32_{arm}_streamwait.control.protocol.json';protocol=read(path)
        parameters=protocol['parameters']
        if (protocol['question_count']!=5000 or protocol['arm']!=arm or protocol['attempt']!=1
                or parameters['visual_token_num']!=32 or parameters['alpha']!=.5
                or parameters['beta']!=(1. if arm=='EADP_beta1' else 2.)
                or parameters['anchorzip']!=(arm=='AZ_beta2') or parameters['max_new_tokens']!=128
                or not protocol['AST_validation']['restoration_ast_identical']
                or protocol['index_trace'] is not False):raise ValueError('Frozen full control protocol differs: '+arm)
        if sha(WORKER)!=protocol['launcher_sha256']:raise ValueError('Full worker launcher SHA differs')
        for filename,expected in protocol['source_and_input_sha256'].items():
            if filename in sources and sources[filename]!=expected:raise ValueError('Conflicting source SHA')
            sources[filename]=expected
        sources[str(path)]=sha(path);sources[protocol['image_manifest']]=protocol['image_manifest_sha256']
        job=dict(arm=arm,attempt=1,control_protocol=str(path),control_protocol_sha256=sha(path),
                 command=protocol['generate_command'],parameters=parameters,output_paths=protocol['output_paths'])
        protected(job);jobs[arm]=job
    sources[str(WORKER)]=sha(WORKER)
    for source in [OUT/'schedule_next_gap_panel.py',OUT/'stream_panel_scheduler.plan.json',
                   ROOT/'Qwen_vl/outputs/audit_followup_20261008/rerun_fast/run_pope_streamwait_control.py']:
        sources[str(source)]=sha(source)
    for lane in ('lane1_v15','lane2_next'):
        path=BATCH/(lane+'_plan.json');sources[str(path)]=sha(path)
        for filename,expected in read(path)['source_sha256'].items():
            if filename in sources and sources[filename]!=expected:raise ValueError('Conflicting main source SHA')
            sources[filename]=expected
    plan=dict(prepared_utc=now(),available_arms=list(ARMS),jobs=jobs,source_and_input_sha256=sources,
              controller_sha256=sha(__file__),environment=UTIL.environment(),minimum_free_mib=MIN_FREE,
              loading_reservation='A live subprocess reserves one slot before any CUDA context; require real own context AND one complete prediction/runtime line before another launch',
              optional_control_dependency='EADP_beta1 may start only after EADP_beta2 full5000 official scoring hard gate passes',
              authorization='User authorized wait-only full E2/AZ2 paired controls and one predefined release beta1 sensitivity control; no parameter search')
    verify(plan)
    if PLAN.exists() or STATE.exists():raise FileExistsError('Preserve existing full controller registration')
    atomic(PLAN,plan)
    atomic(STATE,dict(status='prepared',started_utc=None,selected_arms=[],registered_methods=[],
                      available_arms=list(ARMS),publication_expected_groups=[],plan=str(PLAN),plan_sha256=sha(PLAN),
                      child_pids=[],jobs={},updated_utc=now()))
    command=[sys.executable,str(Path(__file__).resolve()),'--run','--plan',str(PLAN)]
    if include_default:command.append('--include-default-control')
    print(json.dumps(dict(CPU_only=True,GPU_started=False,prepare_only_does_not_register_publication_scope=True,
                         plan=str(PLAN),state=str(STATE),run_command=command,prerequisites=prerequisites()),indent=2))

def validate_arm(job,plan):
    verify(plan);paths=job['output_paths'];score=read(paths['score']);marker=read(paths['finished']);worker_state=read(paths['state'])
    if (worker_state.get('status')!='complete' or worker_state.get('generation_exit_code')!=0
            or marker.get('success') is not True or marker.get('complete') is not True
            or marker.get('n')!=5000 or marker.get('generation_exit_code')!=0
            or marker.get('arm')!=job['arm'] or score.get('success') is not True or score.get('n')!=5000
            or score.get('arm')!=job['arm']):raise ValueError('Incomplete full-control score/marker/state: '+job['arm'])
    if sha(paths['control_protocol'])!=job['control_protocol_sha256']:raise ValueError('Frozen control protocol drift')
    for path,expected in [(paths['prediction'],marker['prediction_sha256']),(paths['score'],marker['score_sha256']),
                          (paths['prediction'],score['prediction_sha256']),(paths['runtime'],score['runtime_sha256'])]:
        if sha(path)!=expected:raise ValueError('Full-control scored artifact SHA differs')
    worker=module(WORKER,'frozen_full_score_checks')
    questions=[json.loads(line) for line in Path(job['parameters']['question_file']).open()]
    fresh=worker.validate_and_score(paths['prediction'],paths['runtime'],questions,job['parameters'])
    if any(score.get(key)!=value for key,value in fresh.items()):raise ValueError('Independent full official rescore differs')
    return dict(success=True,n=5000,accuracy_percent=fresh['accuracy_percent'],official_score=paths['score'],
                score_sha256=sha(paths['score']),prediction_sha256=fresh['prediction_sha256'],runtime_sha256=fresh['runtime_sha256'])

def run(plan_path,include_default):
    plan=read(plan_path);state=read(STATE)
    lock=(STABILITY/'next_text_full_streamwait.controller.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    if state['status']!='prepared' or state['plan_sha256']!=sha(plan_path):raise ValueError('Preserve prior registered controller state/plan')
    verify(plan);UTIL.environment()
    selected=list(ARMS if include_default else ARMS[:2])
    state.update(status='waiting_for_main_and_panel',started_utc=now(),supervisor_pid=os.getpid(),selected_arms=selected,
                 registered_methods=selected,publication_expected_groups=expected_groups(selected),
                 jobs={arm:dict(plan['jobs'][arm],status='pending') for arm in selected},updated_utc=now())
    atomic(STATE,state)
    active={};completed={};failures={}
    def interrupted(signum,frame):raise KeyboardInterrupt('Full controller interrupted')
    signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
    try:
        while True:
            for arm,entry in list(active.items()):
                returned=entry['child'].poll()
                if returned is None:continue
                entry['log'].close();del active[arm]
                if returned:
                    failure='Worker exited '+str(returned);failures[arm]=failure
                    state['jobs'][arm].update(status='failed',returncode=returned,error=failure,finished_utc=now())
                else:
                    verify(plan)
                    try:
                        validation=validate_arm(plan['jobs'][arm],plan);completed[arm]=validation
                        state['jobs'][arm].update(status='complete',returncode=0,validation=validation,finished_utc=now())
                    except Exception as error:
                        failures[arm]=str(error);state['jobs'][arm].update(status='failed',returncode=0,error=str(error),finished_utc=now())
            if 'EADP_beta2' in failures and 'EADP_beta1' in selected and state['jobs']['EADP_beta1']['status']=='pending':
                state['jobs']['EADP_beta1'].update(status='skipped_dependency',error='EADP_beta2 full official scoring gate failed');failures['EADP_beta1']='EADP_beta2 dependency failed'
            pending=[arm for arm in selected if state['jobs'][arm]['status']=='pending' and eligible(arm,completed)]
            if not active and all(state['jobs'][arm]['status'] in ('complete','failed','skipped_dependency') for arm in selected):
                state.update(status='failed' if failures else 'complete',error=failures or None,child_pids=[],finished_utc=now(),updated_utc=now());atomic(STATE,state)
                marker=STABILITY/'next_text_full_streamwait.controller.finished.json'
                if marker.exists():raise FileExistsError('Preserve prior full controller marker')
                atomic(marker,dict(success=not failures,complete=not failures,selected_arms=selected,completed=completed,failures=failures,finished_utc=now()));return
            dependency=prerequisites();gpu=UTIL.gpu_snapshot()
            pids={entry['child'].pid for entry in active.values()}
            progress={entry['child'].pid:has_progress(plan['jobs'][arm]) for arm,entry in active.items()}
            ready=gate(gpu,pids,progress,dependency['ready'])
            if active and not dependency['ready']:raise RuntimeError('Main/panel completion identity changed while controls were running')
            if active and len(ready['contexts'])>2:raise RuntimeError('An external third GPU context appeared; stopping only owned controls')
            state.update(status='running' if active else 'waiting_for_main_and_panel',child_pids=sorted(pids),gpu_gate=ready,
                         prerequisites=dependency,updated_utc=now())
            for arm,entry in active.items():
                state['jobs'][arm].update(status='generating' if progress[entry['child'].pid] else 'loading_reserved',has_complete_prediction_or_runtime=progress[entry['child'].pid])
            atomic(STATE,state)
            if pending and ready['ready']:
                arm=pending[0];job=plan['jobs'][arm];verify(plan);protected(job);UTIL.environment()
                # Gate once more after source checks, then immediately launch one.
                fresh=gate(UTIL.gpu_snapshot(),pids,progress,prerequisites()['ready'])
                if not fresh['ready']:time.sleep(1);continue
                log=Path(job['output_paths']['log']).open('x')
                try:
                    child=subprocess.Popen(job['command'],cwd=ROOT/'LLaVA',env=dict(os.environ,**plan['environment']),
                                           stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                except BaseException:log.close();raise
                active[arm]=dict(child=child,log=log)
                state['jobs'][arm].update(status='loading_reserved',pid=child.pid,process_identity=process(child.pid),started_utc=now(),
                                          generation_launch_gate=fresh)
                state.update(child_pids=sorted([entry['child'].pid for entry in active.values()]),updated_utc=now());atomic(STATE,state)
            time.sleep(1)
    except BaseException as error:
        for arm,entry in active.items():
            UTIL.stop_owned(entry['child']);entry['log'].close()
            state['jobs'][arm].update(status='interrupted_preserved',error=str(error),finished_utc=now())
        state.update(status='failed',error=str(error),child_pids=[],updated_utc=now());atomic(STATE,state);raise

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--run',action='store_true');parser.add_argument('--prepare',action='store_true')
    parser.add_argument('--include-default-control',action='store_true');parser.add_argument('--plan',type=Path,default=PLAN)
    args=parser.parse_args()
    if args.run:run(args.plan,args.include_default_control)
    else:prepare(args.include_default_control)

if __name__=='__main__':main()
