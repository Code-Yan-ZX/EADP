"""Freeze the POPE rerun and add only two input stream dependencies in memory.

Default invocation prepares a CPU-only plan. --generate is guarded by the
coordinator state, so it cannot claim a third model slot. Production sources
and the already-running as-is prediction file remain untouched.
"""
from __future__ import annotations

import argparse
import ast
import copy
import datetime
import fcntl
import hashlib
import importlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
LLAVA = ROOT / 'LLaVA'
CLIP = LLAVA / 'llava/model/multimodal_encoder/clip_encoder.py'
LOADER = OUT / 'pope_loader_runtime.py'
BASE_PROTOCOL = OUT / 'pope_v15_AZ32.protocol.json'
BATCH = OUT.parent / 'rerun_batch'
FINISHED = OUT / 'pope_v15_AZ32.stream_control.finished.json'
SCORER = OUT / 'score_pope_streamwait_control.py'
BASELINE_SCORER = OUT / 'score_pope_streamwait_baseline.py'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def atomic_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2))
    os.replace(temporary, path)


def forward_patch():
    """Return a checked equivalent forward AST, with exactly three new nodes."""
    source = ast.parse(CLIP.read_text())
    cls = next(n for n in source.body if isinstance(n, ast.ClassDef)
               and n.name == 'CLIPVisionTower')
    original = next(n for n in cls.body if isinstance(n, ast.FunctionDef)
                    and n.name == 'forward')
    patched = copy.deepcopy(original)
    branch = next(n for n in patched.body if isinstance(n, ast.If))
    assignments = [i for i, n in enumerate(branch.orelse)
                   if isinstance(n, ast.Assign)
                   and any(isinstance(t, ast.Name) and t.id == 'text_stream'
                           for t in n.targets)]
    if len(assignments) != 1:
        raise RuntimeError('Expected the exact CLIP image/text stream branch')
    position = assignments[0] + 1
    additions = ast.parse(
        'caller_stream = torch.cuda.current_stream(device=self.device)\n'
        'image_stream.wait_stream(caller_stream)\n'
        'text_stream.wait_stream(caller_stream)\n'
    ).body
    branch.orelse[position:position] = additions
    restored = copy.deepcopy(patched)
    restored_branch = next(n for n in restored.body if isinstance(n, ast.If))
    removed = restored_branch.orelse[position:position + 3]
    del restored_branch.orelse[position:position + 3]
    if (ast.dump(restored) != ast.dump(original)
            or [ast.dump(n) for n in removed] != [ast.dump(n) for n in additions]):
        raise RuntimeError('Patch changes more than caller capture and two waits')
    patched = ast.fix_missing_locations(patched)
    module = ast.fix_missing_locations(ast.Module(body=[patched], type_ignores=[]))
    # Compile without importing torch or creating a CUDA context.
    compile(module, str(CLIP) + ':streamwait_control', 'exec')
    return module, dict(
        production_file=str(CLIP), production_source_sha256=sha(CLIP),
        original_forward_ast_sha256=hashlib.sha256(ast.dump(original).encode()).hexdigest(),
        patched_forward_ast_sha256=hashlib.sha256(ast.dump(patched).encode()).hexdigest(),
        restoration_ast_identical=True,
        inserted_nodes=[ast.unparse(n) for n in additions],
        preserved=['original math', 'original no_grad decorator',
                   'original trailing torch.cuda.synchronize()',
                   'list and attention branches', 'allocation and precision settings'],
        record_stream_added=False,
        patched_forward_source=ast.unparse(patched),
    )


def output_paths(anchorzip):
    name = 'pope_v15_AZ32_streamwait' if anchorzip else 'pope_v15_EADP32_streamwait'
    return dict(output=OUT / (name + '.jsonl'), log=OUT / (name + '.log'),
                protocol=OUT / (name + '.protocol.json'),
                plan=OUT / (name + '.plan.json'),
                state=OUT / (name + '.controller.state.json'),
                patch_validation=OUT / (name + '.ast_validation.json'))


def prepare(anchorzip=True):
    base = json.loads(BASE_PROTOCOL.read_text())
    for path, digest in base['source_and_input_sha256'].items():
        if sha(path) != digest:
            raise RuntimeError('As-is source/input identity changed: ' + path)
    if (base['question_count'] != 8910 or base['parameters']['visual_token_num'] != 32
            or base['parameters']['temperature'] != 0
            or base['parameters']['alpha'] != .5 or base['parameters']['beta'] != 2.
            or base['parameters']['max_new_tokens'] != 128):
        raise RuntimeError('As-is frozen protocol changed')
    module, validation = forward_patch()
    paths = output_paths(anchorzip)
    params = dict(base['parameters'], anchorzip=anchorzip)
    command = [sys.executable, str(Path(__file__).resolve()), '--worker',
               '--model-path', params['model_path'], '--question-file', base['question_file'],
               '--image-folder', base['image_folder'], '--answers-file', str(paths['output']),
               '--temperature', '0', '--conv-mode', params['conv_mode'],
               '--visual_token_num', '32', '--beta', '2.0', '--alpha', '0.5',
               '--max_new_tokens', '128', '--num_beams', '1',
               '--num-chunks', '1', '--chunk-idx', '0']
    if anchorzip:
        command.append('--anchorzip')
    plan = dict(protocol='pope_loader_streamwait_only_control', prepared_utc=now(),
                parameters=params, question_count=8910, question_file=base['question_file'],
                question_sha256=sha(base['question_file']), image_folder=base['image_folder'],
                baseline_protocol=str(BASE_PROTOCOL), baseline_protocol_sha256=sha(BASE_PROTOCOL),
                source_and_input_sha256=dict(base['source_and_input_sha256']),
                launcher_source_sha256=sha(__file__), AST_validation=validation,
                output=str(paths['output']), log=str(paths['log']),
                protocol_sidecar=str(paths['protocol']), generate_command=command,
                runtime_variant='in-memory only: caller capture + image/text wait_stream',
                record_stream_added=False, concurrent_next_lane_required=True,
                release_marker=str(FINISHED),
                release_meaning='Legal complete control and scoring succeeded; zero disagreement is not required',
                production_sources_modified=False,
                causal_limit='Concurrent one-A40 control; load timing and individual Next samples are not identical')
    atomic_json(paths['patch_validation'], validation)
    atomic_json(paths['plan'], plan)
    return plan, paths


def ready_state():
    state_path = BATCH / 'lane1_v15_state.json'
    plan_path = BATCH / 'lane1_v15_plan.json'
    if not state_path.is_file() or not plan_path.is_file():
        return None
    state = json.loads(state_path.read_text())
    plan = json.loads(plan_path.read_text())
    predecessor = plan.get('wait_pid')
    if predecessor and Path('/proc/' + str(predecessor)).exists():
        return None
    if state.get('status') != 'waiting_after_predecessor' or state.get('child_pid') is not None:
        return None
    apps = subprocess.check_output(
        ['nvidia-smi', '--query-compute-apps=pid,used_memory', '--format=csv,noheader'],
        text=True).strip().splitlines()
    processes = []
    for entry in apps:
        pid = int(entry.split(',')[0].strip())
        proc = Path('/proc/' + str(pid) + '/cmdline')
        command = proc.read_bytes().replace(b'\0', b' ').decode(errors='replace') if proc.exists() else ''
        processes.append(dict(pid=pid, command=command, gpu_display=entry))
    # The other slot must be the already-authorized NeXT model, not a third model.
    next_models = [p for p in processes if 'llava-v1.6-vicuna-7b' in p['command']]
    unrelated_models = [p for p in processes if p not in next_models]
    if len(next_models) != 1 or unrelated_models:
        return None
    return dict(confirmed_utc=now(), lane1_state=state, next_gpu_processes=next_models,
                gpu_before_launch=subprocess.check_output(
                    ['nvidia-smi', '--query-gpu=memory.total,memory.used,utilization.gpu',
                     '--format=csv,noheader'], text=True).strip())


def worker():
    # Remove only the adapter switch. All remaining argv is consumed unchanged
    # by the exact as-is loader (including its input non_blocking=True transfers).
    sys.argv.remove('--worker')
    frozen = json.loads(BASE_PROTOCOL.read_text())['source_and_input_sha256']
    for path, digest in frozen.items():
        if sha(path) != digest:
            raise RuntimeError('Frozen source/input changed before worker: ' + path)
    sys.path.insert(0, str(LLAVA))
    clip_module = importlib.import_module('llava.model.multimodal_encoder.clip_encoder')
    module, validation = forward_patch()
    namespace = dict(clip_module.__dict__)
    exec(compile(module, str(CLIP) + ':streamwait_control', 'exec'), namespace)
    clip_module.CLIPVisionTower.forward = namespace['forward']
    print(json.dumps(dict(runtime_patch=validation, production_modified=False)), flush=True)
    runpy.run_path(str(LOADER), run_name='__main__')


def main():
    if '--worker' in sys.argv:
        worker()
        return
    parser = argparse.ArgumentParser()
    parser.add_argument('--generate', action='store_true')
    parser.add_argument('--wait-until-ready', action='store_true')
    parser.add_argument('--no-anchorzip', dest='anchorzip', action='store_false', default=True,
                        help='Prepare a separate same-budget EADP control; never launched implicitly')
    args = parser.parse_args()
    plan, paths = prepare(args.anchorzip)
    print(json.dumps(plan, ensure_ascii=False, indent=2), flush=True)
    if not args.generate:
        return
    if not args.anchorzip:
        raise RuntimeError('EADP32 future branch is prepare-only until root authorizes its launch')
    controller_lock = paths['state'].with_suffix('.lock').open('w')
    fcntl.flock(controller_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    if FINISHED.exists():
        raise FileExistsError('Controlled release marker already exists')
    baseline_plan, baseline_paths = prepare(False)
    stages = [(plan, paths, SCORER), (baseline_plan, baseline_paths, BASELINE_SCORER)]
    for stage_plan, stage_paths, scorer in stages:
        for p in (stage_paths['output'], stage_paths['log'], stage_paths['protocol']):
            if p.exists():
                raise FileExistsError('Preserve existing controlled artifact: ' + str(p))
        if not scorer.is_file():
            raise FileNotFoundError('CPU scorer must exist before controlled generation: ' + str(scorer))
    state = dict(controller_pid=os.getpid(), started_utc=now(), status='waiting',
                 plan=str(paths['plan']), output=str(paths['output']), child_pid=None,
                 stage_plans=[str(p['plan']) for _, p, _ in stages], completed_stages=[])
    atomic_json(paths['state'], state)
    ready = ready_state()
    while ready is None and args.wait_until_ready:
        print(json.dumps(dict(status='waiting_for_as_is_exit_and_lane1_gate', utc=now())), flush=True)
        state.update(status='waiting', updated_utc=now())
        atomic_json(paths['state'], state)
        time.sleep(5)
        ready = ready_state()
    if ready is None:
        raise RuntimeError('Root-coordinated lane1 gate or concurrent NeXT process is not ready')
    env = dict(os.environ, PYTHONPATH=str(LLAVA), HF_HUB_OFFLINE='1',
               TRANSFORMERS_OFFLINE='1', OMP_NUM_THREADS='4', MKL_NUM_THREADS='4')
    for index, (stage_plan, stage_paths, scorer) in enumerate(stages):
        # Between the two controlled jobs, the other lane may be loading its
        # next NeXT arm. Wait until that GPU child is visible before starting.
        ready = ready_state()
        while ready is None:
            state.update(status='waiting_for_next_concurrency', current_stage=index + 1,
                         child_pid=None, updated_utc=now())
            atomic_json(paths['state'], state)
            time.sleep(5)
            ready = ready_state()
        protocol = dict(stage_plan, started_utc=now(), concurrency_at_launch=ready,
                        scorer_source_sha256=sha(scorer), controlled_group_size=2,
                        controlled_group_stage=index + 1,
                        frozen_mode_note='mode=rtg applies only when AnchorZip installation is enabled')
        atomic_json(stage_paths['protocol'], protocol)
        with stage_paths['log'].open('x') as log:
            process = subprocess.Popen(stage_plan['generate_command'], cwd=LLAVA, env=env,
                                       stdout=log, stderr=subprocess.STDOUT)
            state.update(status='generating', current_stage=index + 1,
                         stage_output=str(stage_paths['output']), child_pid=process.pid,
                         updated_utc=now(), concurrency_at_launch=ready)
            atomic_json(paths['state'], state)
            returned = process.wait()
            if returned != 0:
                state.update(status='failed', generation_returncode=returned, updated_utc=now())
                atomic_json(paths['state'], state)
                raise RuntimeError('Controlled generation failed: ' + str(returned))
        protocol.update(generation_exit_code=0, generation_finished_utc=now())
        atomic_json(stage_paths['protocol'], protocol)
        state.update(status='scoring', child_pid=None, generation_returncode=0, updated_utc=now())
        atomic_json(paths['state'], state)
        command = [sys.executable, str(scorer), '--generation-returncode', '0']
        if index == 0:
            command.extend(['--wait-result', str(stage_paths['output'])])
        else:
            # Release only after both complete fixed-budget arms are scored;
            # no condition depends on whether AnchorZip wins or is repeatable.
            command.extend(['--marker', str(FINISHED)])
        subprocess.run(command, cwd=ROOT, env=env, check=True)
        state['completed_stages'].append(dict(stage=index + 1,
                                             output=str(stage_paths['output']),
                                             protocol=str(stage_paths['protocol']),
                                             completed_utc=now()))
        atomic_json(paths['state'], state)
    state.update(status='complete', marker=str(FINISHED), updated_utc=now())
    atomic_json(paths['state'], state)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        if '--generate' in sys.argv:
            state_path = output_paths(True)['state']
            if state_path.is_file():
                state = json.loads(state_path.read_text())
                if state.get('controller_pid') == os.getpid():
                    state.update(status='failed', error=str(error), updated_utc=now())
                    atomic_json(state_path, state)
        raise
